# AI CASUAL STUDIO OS — INDEX

Версия: 1.1
Дата: 2026-07-14

---

## Как пользоваться

Эта система организована как **конструктор**:

```
Жанр (что делает игрок)
  + Механика (какая логика)
  + Система (как работает)
  + Компонент (как выглядит)
= Игра
```

Перед началом работы ИИ читает **PROJECT_STATE.md** в корне и понимает, где находится проект.

---

## Если задача...

### ...про жанр / что делает игрок
- `13_GENRES/MERGE.md`
- `13_GENRES/CLICKER.md`
- `13_GENRES/IDLE.md`
- `13_GENRES/TYCOON.md`
- `13_GENRES/MATCH3.md`
- `13_GENRES/PUZZLE.md`
- `13_GENRES/TD.md`
- `13_GENRES/SURVIVOR.md`
- `13_GENRES/INCREMENTAL.md`
- `13_GENRES/COLLECTOR.md`
- `13_GENRES/BUILDER.md`
- `13_GENRES/CORE.md` (общие принципы)

### ...про механику / retention / gameplay
- `14_MECHANICS/OFFLINE_PROGRESS.md`
- `14_MECHANICS/QUESTS.md`
- `14_MECHANICS/ACHIEVEMENTS.md`
- `14_MECHANICS/DAILY_REWARD.md`
- `14_MECHANICS/STREAK.md`
- `14_MECHANICS/PRESTIGE.md`
- `14_MECHANICS/REBIRTH.md`
- `14_MECHANICS/UPGRADES.md`
- `14_MECHANICS/CHESTS.md`
- `14_MECHANICS/LOOT.md`
- `14_MECHANICS/SKILLS.md`
- `14_MECHANICS/INVENTORY.md`
- `14_MECHANICS/CRAFTING.md`
- `14_MECHANICS/SHOP.md`
- `14_MECHANICS/ENERGY.md`
- `14_MECHANICS/ADS.md`
- `14_MECHANICS/LEADERBOARD.md`
- `14_MECHANICS/CLOUD_SAVE.md`
- `14_MECHANICS/TUTORIAL.md`
- `14_MECHANICS/BATTLE_PASS.md`
- `14_MECHANICS/CORE.md` (общие принципы)

### ...про систему / как работает
- `15_SYSTEMS/SAVE_SYSTEM.md`
- `15_SYSTEMS/ECONOMY_SYSTEM.md`
- `15_SYSTEMS/UI_SYSTEM.md`
- `15_SYSTEMS/INPUT_SYSTEM.md`
- `15_SYSTEMS/AUDIO_SYSTEM.md`
- `15_SYSTEMS/PROGRESSION_SYSTEM.md`
- `15_SYSTEMS/SPAWN_SYSTEM.md`
- `15_SYSTEMS/ANIMATION_SYSTEM.md`
- `15_SYSTEMS/NOTIFICATION_SYSTEM.md`
- `15_SYSTEMS/EVENT_SYSTEM.md`
- `15_SYSTEMS/CORE.md` (общие принципы)

### ...про UI компонент
- `16_COMPONENTS/BUTTON.md`
- `16_COMPONENTS/POPUP.md`
- `16_COMPONENTS/TOAST.md`
- `16_COMPONENTS/HUD.md`
- `16_COMPONENTS/CURRENCY_PANEL.md`
- `16_COMPONENTS/LOADING.md`
- `16_COMPONENTS/TUTORIAL_ARROW.md`
- `16_COMPONENTS/NOTIFICATION.md`
- `16_COMPONENTS/CONFIRM_DIALOG.md`
- `16_COMPONENTS/WINDOW.md`
- `16_COMPONENTS/REWARD_SCREEN.md`
- `16_COMPONENTS/README.md` (как пользоваться)

### ...про платформу / Яндекс / монетизацию
- `06_BIBLES/YANDEX_GAMES_BIBLE.md` — SDK, реклама, модерация
- `06_BIBLES/MONETIZATION_BIBLE.md` — Rewarded, Interstitial, IAP
- `06_BIBLES/AUDIO_BIBLE.md` — звук, музыка
- `06_BIBLES/ANALYTICS_BIBLE.md` — события, KPI
- `06_BIBLES/LIVEOPS_BIBLE.md` — обновления, события
- `06_BIBLES/AI_DEVELOPER_BIBLE.md` — стек, стиль кода
- `06_BIBLES/UI_UX_BIBLE.md` — UI/UX
- `06_BIBLES/ECONOMY_BIBLE.md` — валюты, прогрессия
- `06_BIBLES/MERGE_BIBLE.md` — жанр Merge
- `06_BIBLES/PLAYER_PSYCHOLOGY.md` — психология игрока
- `06_BIBLES/FIRST_30_SECONDS.md` — онбординг
- `06_BIBLES/FIRST_10_MINUTES.md` — первая сессия
- `06_BIBLES/RETENTION_PSYCHOLOGY.md` — D1/D7/D30
- `06_BIBLES/EMOTIONAL_DESIGN.md` — эмоции
- `06_BIBLES/MOTIVATION.md` — мотивация
- `06_BIBLES/FRICTION.md` — что убрать
- `06_BIBLES/REWARDS_PSYCHOLOGY.md` — награды
- `06_BIBLES/COGNITIVE_LOAD.md` — нагрузка

### ...про поведение ИИ / правила
- `01_BEHAVIOR/HOW_TO_THINK.md` — как думать
- `01_BEHAVIOR/SELF_REVIEW.md` — после задачи
- `01_BEHAVIOR/MINIMAL_CHANGE.md` — минимальные изменения
- `01_BEHAVIOR/DO_NOT_OVERENGINEER.md` — не усложнять
- `01_BEHAVIOR/WHEN_TO_REFACTOR.md` — когда рефакторить
- `01_BEHAVIOR/WHEN_TO_SAY_NO.md` — когда отказать
- `01_BEHAVIOR/PLAYER_FIRST.md` — игрок важнее
- `01_BEHAVIOR/RELEASE_FIRST.md` — релиз важнее
- `01_BEHAVIOR/RISK_ANALYSIS.md` — оценка рисков
- `02_RULES/AI_RULES.md` — правила для ИИ
- `02_RULES/CODING_RULES.md` — стиль кода
- `02_RULES/DOCUMENTATION_RULES.md` — стиль документации
- `02_RULES/COMMUNICATION_RULES.md` — общение
- `02_RULES/DECISION_RULES.md` — принятие решений

### ...про роль / кто я в проекте
- `03_ROLES/PRODUCER.md` — решает "нужно ли"
- `03_ROLES/ARCHITECT.md` — структура
- `03_ROLES/PROGRAMMER.md` — реализует
- `03_ROLES/QA.md` — ищет баги
- `03_ROLES/GAME_DESIGNER.md` — игровой дизайн
- `03_ROLES/ART_DIRECTOR.md` — визуал
- `03_ROLES/UX_DESIGNER.md` — UX
- `03_ROLES/BALANCE_DESIGNER.md` — баланс
- `03_ROLES/ANALYTICS.md` — метрики
- `03_ROLES/RELEASE_MANAGER.md` — релиз
- `03_ROLES/LIVEOPS.md` — обновления

### ...про процесс / пайплайн
- `04_PIPELINE/MASTER_PIPELINE.md` — общая схема
- `04_PIPELINE/PIPELINE_STAGES.md` — этапы
- `04_PIPELINE/IDEA.md` — идея
- `04_PIPELINE/VALIDATION.md` — валидация
- `04_PIPELINE/PREPRODUCTION.md` — подготовка
- `04_PIPELINE/DEVELOPMENT.md` — разработка
- `04_PIPELINE/QA_PIPELINE.md` — тестирование
- `04_PIPELINE/RELEASE_PIPELINE.md` — релиз
- `04_PIPELINE/POST_RELEASE.md` — после релиза

### ...про философию / ценности
- `00_CORE/MISSION.md` — зачем всё это
- `00_CORE/VISION.md` — куда движемся
- `00_CORE/VALUES.md` — главные принципы
- `00_CORE/PHILOSOPHY.md` — наша философия
- `00_CORE/SUCCESS.md` — что считаем успехом
- `00_CORE/PROJECT_LIFECYCLE.md` — жизненный цикл

### ...про проект / артефакты
- `PROJECT_STATE.md` — текущее состояние Studio OS
- `CHANGELOG.md` — история изменений
- `VERSION.md` — версии
- `MISSING.md` — что отсутствует
- `MERGE_CANDIDATES.md` — кандидаты на объединение
- `NEXT_TASK.md` — следующая задача
- `08_PROJECT_TEMPLATE/PROJECT.md` — шаблон нового проекта
- `08_PROJECT_TEMPLATE/GAME_DESIGN.md` — GDD
- `08_PROJECT_TEMPLATE/ECONOMY.md` — экономика
- `08_PROJECT_TEMPLATE/BALANCE.md` — баланс
- `08_PROJECT_TEMPLATE/ART_DIRECTION.md` — арт
- `08_PROJECT_TEMPLATE/ANALYTICS.md` — аналитика
- `08_PROJECT_TEMPLATE/DECISIONS.md` — решения
- `08_PROJECT_TEMPLATE/CHANGELOG.md` — изменения

### ...про примеры
- `98_EXAMPLES/MergeFarm/case_*.md` — кейс-стади Merge Farm
- `98_EXAMPLES/MergeFarm/README.md` — описание проекта
- `98_EXAMPLES/IdleGarden/README.md` — заглушка
- `98_EXAMPLES/ClickerTemplate/README.md` — заглушка

### ...про паттерны
- `07_PATTERNS/PATTERNS.md` — что работает
- `07_PATTERNS/ANTI_PATTERNS.md` — что не работает
- `07_PATTERNS/LESSONS_LEARNED.md` — уроки
- `07_PATTERNS/CASE_STUDIES.md` — шаблон кейс-стади
- `07_PATTERNS/STUDIO_MEMORY.md` — память студии
- `07_PATTERNS/POSTMORTEM.md` — постмортем

### ...про знания
- `11_REFERENCE/AI_DEVELOPER_BIBLE.md` (стек)
- `11_REFERENCE/GAMEPLAY_RULES.md` (правила)
- `11_REFERENCE/GAME_ECONOMY.md` (экономика)
- `11_REFERENCE/RETENTION.md` (удержание)
- `11_REFERENCE/LIVEOPS.md` (обновления)
- `11_REFERENCE/PLAYER_PSYCHOLOGY.md` (психология)
- `11_REFERENCE/STUDIO_PRINCIPLES.md` (принципы студии)

### ...про архитектурные решения
- `20_DECISIONS/README.md` (формат ADR)
- `20_DECISIONS/0001-html5.md`
- `20_DECISIONS/0002-vite.md`
- `20_DECISIONS/0003-svg.md`
- `20_DECISIONS/0004-no-react.md`
- `20_DECISIONS/0005-no-framework.md`
- `20_DECISIONS/0006-dom-render.md`

### ...про чек-листы
- `10_CHECKLISTS/PRE_RELEASE.md`
- `10_CHECKLISTS/QA_CHECKLIST.md`
- `10_CHECKLISTS/YANDEX_GAMES.md`

### ...про готовые промпты
- `09_PROMPTS/MASTER_PROMPT.md` — главный
- `09_PROMPTS/REVIEWER.md` — для ревью
- `09_PROMPTS/AI_TASK_TEMPLATE.md` — шаблон задачи
- `09_PROMPTS/AI_COMMUNICATION.md` — общение
- `09_PROMPTS/AI_LIMITATIONS.md` — ограничения
- `09_PROMPTS/PROMPT_RULES.md` — правила
- `09_PROMPTS/ARENA.md` — особенности Arena
- `09_PROMPTS/PROMPT_EXTRA_*.md` — специализированные промпты

### ...про существующие проекты
- `90_PROJECTS/_TEMPLATE/` — шаблон для нового проекта
- `90_PROJECTS/_TEMPLATE/src/` — готовая код-база
- `90_PROJECTS/_TEMPLATE/src/ui/` — для UI компонентов
- `90_PROJECTS/_TEMPLATE/src/core/` — для жанровой логики

---

## Quick links

- [PROJECT_STATE.md](PROJECT_STATE.md) — текущее состояние
- [CHANGELOG.md](CHANGELOG.md) — история версий
- [VERSION.md](VERSION.md) — версии Studio OS
- [MISSING.md](MISSING.md) — что нужно добавить
- [MERGE_CANDIDATES.md](MERGE_CANDIDATES.md) — что объединить
- [NEXT_TASK.md](NEXT_TASK.md) — что делать дальше
- [DEPENDENCY_MAP.md](DEPENDENCY_MAP.md) — связи между слоями
- [FIRST_DAY_CHECKLIST.md](FIRST_DAY_CHECKLIST.md) — день 1 новой игры
- [BOOTSTRAP_KIT.md](BOOTSTRAP_KIT.md) — запуск за 1 час

---

## Правило системы

> **Новые документы создаются только если информация не помещается ни в один существующий документ.**
