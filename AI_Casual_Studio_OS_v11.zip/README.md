# AI CASUAL STUDIO OS

**Версия:** 1.1
**Дата:** 2026-07-14

---

## Что это

Документация, которая позволяет одному человеку + ИИ выпускать казуальные игры для Яндекс Игр за 5-10 дней.

## Архитектура

```
00_CORE              — философия и цели
01_BEHAVIOR          — как ИИ принимает решения
02_RULES             — формальные правила
03_ROLES             — 11 ролей виртуальной команды
04_PIPELINE          — путь от идеи до релиза
06_BIBLES            — глубокие справочники
07_PATTERNS          — паттерны и антипаттерны
08_PROJECT_TEMPLATE  — шаблоны артефактов
90_PROJECTS          — реальные и шаблонные проекты
09_PROMPTS           — готовые промпты
10_CHECKLISTS        — чек-листы
11_REFERENCE         — база знаний
98_EXAMPLES          — примеры
13_GENRES            — жанровые спецификации
14_MECHANICS         — переиспользуемые игровые механики
15_SYSTEMS           — универсальные системы
16_COMPONENTS        — готовые UI-компоненты
20_DECISIONS         — Architecture Decision Records
```

## Игра = Жанр + Механики + Системы + Компоненты

Примеры:
- **Merge Farm** = `MERGE` + `Offline + Quests + Achievements + Daily + Chests` + `Save/UI/Audio` + `Button/Popup/HUD/RewardScreen`
- **Простой кликер** = `CLICKER` + `Upgrades + Prestige + Ads` + `Save/UI/Audio` + `Button/HUD`

## Быстрый старт

1. Прочитайте `00_CORE/MISSION.md`
2. Прочитайте `01_BEHAVIOR/HOW_TO_THINK.md`
3. Выберите жанр в `13_GENRES/`
4. Подберите механики в `14_MECHANICS/`
5. Соберите UI из `16_COMPONENTS/`
6. Скопируйте `_TEMPLATE/` из `90_PROJECTS/`
7. Начните делать игру

## Версия

v1.1 — добавлены COMPONENTS и DECISIONS. Подробности в `CHANGELOG.md`.
