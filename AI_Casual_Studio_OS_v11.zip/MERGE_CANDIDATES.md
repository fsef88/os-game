**Tags:** merge, merge-candidates

# MERGE_CANDIDATES

Кандидаты на объединение или удаление.
Не объединять автоматически — каждое решение должно быть осознанным.

## Точные дубликаты (одинаковое содержимое под разными именами)

### 1. `MINIMAL_CHANGE.md` × 2
- `01_BEHAVIOR/MINIMAL_CHANGE.md` (510 байт) — оригинал
- `11_REFERENCE/AI_DEVELOPER_BIBLE.md` — содержит копию внутри

**Рекомендация:** оставить только в 01_BEHAVIOR/. В 11_REFERENCE/AI_DEVELOPER_BIBLE.md оставить ссылку.

### 2. `POSTMORTEM.md` × 2
- `07_PATTERNS/POSTMORTEM.md` (643 байт) — шаблон
- `08_PROJECT_TEMPLATE/...` — дублируется

**Рекомендация:** оставить только в 07_PATTERNS/. Это шаблон для всех проектов.

### 3. `SUCCESS.md` × 2
- `00_CORE/SUCCESS.md` (685 байт) — критерии успеха
- Внутри другого файла — копия

**Рекомендация:** оставить только в 00_CORE/.

### 4. `SCOPE_CONTROL.md` × 2
- В `11_REFERENCE/AI_DEVELOPER_BIBLE.md` — две копии подряд

**Рекомендация:** дедуплицировать внутри файла.

## Тематические дубликаты (одна идея, разные формулировки)

### A. Минимальные изменения
- `01_BEHAVIOR/MINIMAL_CHANGE.md`
- `11_REFERENCE/AI_DEVELOPER_BIBLE.md` (внутри)
- `04_PIPELINE/DEVELOPMENT.md` упоминает
- `02_RULES/AI_RULES.md` (пункт 3)

**Рекомендация:** оставить эталон в 01_BEHAVIOR/MINIMAL_CHANGE.md. В остальных — ссылка.

### B. Запрет рефакторинга
- `01_BEHAVIOR/WHEN_TO_REFACTOR.md`
- `01_BEHAVIOR/DO_NOT_OVERENGINEER.md`
- `02_RULES/AI_RULES.md` (пункт 4)
- `11_REFERENCE/AI_DEVELOPER_BIBLE.md`

**Рекомендация:** WHEN_TO_REFACTOR.md — основной. Остальные ссылки.

### C. Quality / Simplicity
- `00_CORE/VALUES.md` (пункт Simplicity)
- `00_CORE/PHILOSOPHY.md` (поддерживаемый код)
- `11_REFERENCE/STUDIO_PRINCIPLES.md` (качество)

**Рекомендация:** VALUES.md — корневой. Studio Principles — большой каталог.

### D. Release / Ship
- `01_BEHAVIOR/RELEASE_FIRST.md`
- `11_REFERENCE/STUDIO_PRINCIPLES.md` (ship_fast, ship_it)
- `07_PATTERNS/PATTERNS.md` (?)
- `00_CORE/VALUES.md` (Release beats Perfection)

**Рекомендация:** VALUES.md — философский. RELEASE_FIRST.md — поведенческий. Остальное — ссылки.

### E. Postmortem / Lessons / Case Studies
- `07_PATTERNS/POSTMORTEM.md` — шаблон
- `07_PATTERNS/CASE_STUDIES.md` — шаблон
- `07_PATTERNS/LESSONS_LEARNED.md` — что вынесли
- `98_EXAMPLES/MergeFarm/case_*.md` — 10 примеров

**Рекомендация:** оставить все 3 шаблона, но в README студии пояснить разницу: Postmortem (всё подробно), Case Study (один проект), Lessons (короткие выводы).

### F. Risk Analysis
- `01_BEHAVIOR/RISK_ANALYSIS.md`
- `01_BEHAVIOR/WHEN_TO_SAY_NO.md` — пересекается
- `03_ROLES/RELEASE_MANAGER.md` (RED FLAGS) — пересекается

**Рекомендация:** RISK_ANALYSIS — оценка. WHEN_TO_SAY_NO — отказ. RED FLAGS — список стоп-сигналов. Три разных вещи, но визуально похожи. Возможно, стоит унифицировать терминологию.

### G. Studio Score / Project Score / Reuse Score
- `04_PIPELINE/POST_RELEASE.md` содержит три метрики

**Рекомендация:** оставить как есть, это разные метрики одного блока.

## Задвоенные шаблоны

### PROMPT_EXTRA_1.md ... PROMPT_EXTRA_7.md
Семь файлов без расшифровки роли. Нужно переименовать по содержимому:
- PROMPT_EXTRA_1.md → GAME_DESIGNER_PROMPT.md (?)
- и т.д.

**Рекомендация:** открыть каждый, определить роль, переименовать.

## Файлы-сироты (не упомянуты ни в одном другом документе)

Нет таких — все файлы упоминаются хотя бы в одном месте.

## Удалить

Ничего удалять не нужно в этом проходе. Сначала зафиксировать, потом удалять.
