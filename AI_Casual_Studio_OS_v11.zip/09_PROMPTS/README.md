# 09_PROMPTS

Версия: 1.0
Дата: 2026-07-14

**Tags:** prompts

---

## Иерархия промптов

```
MASTER_PROMPT
    ↓
ROLE_PROMPTS       (кто ты)
    ↓
TASK_PROMPTS       (что делать)
```

## MASTER (1 файл)

- `MASTER_PROMPT.md` — главный промпт. Задаёт контекст: "Ты работаешь в Studio OS. Сначала прочитай PROJECT_STATE, потом свою роль."

## ROLE_PROMPTS (по 1 на роль)

- `PRODUCER_PROMPT.md`
- `ARCHITECT_PROMPT.md`
- `PROGRAMMER_PROMPT.md`
- `QA_PROMPT.md`
- `GAME_DESIGNER_PROMPT.md`
- `ART_DIRECTOR_PROMPT.md`
- `REVIEWER_PROMPT.md`

## TASK_PROMPTS (для конкретных задач)

- `AI_TASK_TEMPLATE.md` — шаблон любой задачи
- `AI_COMMUNICATION.md` — как общаться
- `AI_LIMITATIONS.md` — что ИИ не может
- `PROMPT_RULES.md` — правила промптов
- `ARENA.md` — особенности Arena AI
- `PROMPT_EXTRA_*.md` — специализированные промпты (UI, L10N, etc.)

## Использование

```text
1. Прочитать PROJECT_STATE.md
2. Прочитать MASTER_PROMPT.md
3. Прочитать ROLE_PROMPT.md (свою роль)
4. Прочитать AI_TASK_TEMPLATE.md
5. Заполнить задачу
6. Сделать Self Review (см. 01_BEHAVIOR/SELF_REVIEW.md)
7. Обновить документацию
```
