// Двойное сохранение: локально (всегда) + облако (критичное).
// Адаптировано из merge-farm.

import { sdk } from './sdk';

const LOCAL_KEY = 'game_save';
const SAVE_THROTTLE_MS = 5000;

let lastSaveTime = 0;
let pendingSave: any = null;

export interface SaveData {
  version: string;
  timestamp: number;
  // state
  state: any;
  // analytics
  sessionCount: number;
  totalPlayTime: number;
  lastSeen: number;
}

export async function saveGame(state: any, force = false): Promise<boolean> {
  const now = Date.now();

  // Всегда сохраняем локально
  const data: SaveData = {
    version: state.version || '0.1.0',
    timestamp: now,
    state,
    sessionCount: (state.sessionCount || 0) + (force ? 0 : 1),
    totalPlayTime: state.totalPlayTime || 0,
    lastSeen: now,
  };

  try {
    localStorage.setItem(LOCAL_KEY, JSON.stringify(data));
  } catch (e) {
    console.error('[Save] localStorage failed', e);
  }

  // Throttle облако
  if (!force && now - lastSaveTime < SAVE_THROTTLE_MS) {
    pendingSave = data;
    scheduleSave();
    return true;
  }

  lastSaveTime = now;
  return await sdk.saveData(data);
}

let saveTimeout: number | null = null;
function scheduleSave() {
  if (saveTimeout) return;
  saveTimeout = window.setTimeout(async () => {
    saveTimeout = null;
    if (pendingSave) {
      const data = pendingSave;
      pendingSave = null;
      lastSaveTime = Date.now();
      await sdk.saveData(data);
    }
  }, SAVE_THROTTLE_MS);
}

export async function loadGame(): Promise<SaveData | null> {
  // 1. Пробуем облако
  const cloud = await sdk.getData();
  // 2. Локальный
  const localStr = localStorage.getItem(LOCAL_KEY);
  const local = localStr ? JSON.parse(localStr) : null;

  if (!cloud || Object.keys(cloud).length === 0) {
    return local;
  }
  if (!local) {
    return cloud;
  }
  // Мерджим: приоритет у более нового timestamp
  return (cloud.timestamp || 0) > (local.timestamp || 0) ? cloud : local;
}

export function clearSave() {
  localStorage.removeItem(LOCAL_KEY);
  console.log('[Save] Cleared');
}
