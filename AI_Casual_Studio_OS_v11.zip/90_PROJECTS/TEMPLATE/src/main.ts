import { initGame } from './core/init';
import './styles/main.css';

initGame();
