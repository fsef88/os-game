// HUD: верх (монеты, кристаллы) + низ (boost).
// Адаптировать под жанр.

import { state } from './state';
import { addMoney } from './state';

export function initHUD(container: HTMLElement) {
  const hud = document.createElement('div');
  hud.className = 'hud';
  hud.innerHTML = `
    <div class="hud-top">
      <div class="hud-money" id="hud-money">💰 <span id="hud-money-value">0</span></div>
      <div class="hud-crystals" id="hud-crystals" style="display:none">💎 <span id="hud-crystals-value">0</span></div>
      <div class="hud-income" id="hud-income" style="display:none">+0/с</div>
    </div>
    <div class="hud-bottom" id="hud-bottom">
      <!-- кнопки boost'ов добавляются динамически -->
    </div>
  `;
  container.appendChild(hud);

  // Подписка на изменения
  state.subscribe(updateHUD);
  updateHUD();
}

function updateHUD() {
  const s = state.get();
  const moneyEl = document.getElementById('hud-money-value');
  const crystalsEl = document.getElementById('hud-crystals-value');
  if (moneyEl) moneyEl.textContent = formatNumber(s.money);
  if (crystalsEl) crystalsEl.textContent = String(s.crystals);
}

function formatNumber(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M';
  if (n >= 1_000) return (n / 1_000).toFixed(1) + 'K';
  return String(Math.floor(n));
}
