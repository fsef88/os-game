# src/

## Структура

```
src/
├── main.ts            # точка входа
├── config.ts          # все константы
├── state.ts           # глобальное состояние
├── sdk.ts             # Yandex SDK + Mock
├── save.ts            # двойной save
├── analytics.ts       # события, KPI
├── i18n.ts            # локализация
├── hud.ts             # верх-низ UI
├── core/
│   └── init.ts        # инициализация
├── ui/                # жанровые UI-компоненты
├── styles/
│   └── main.css       # базовые стили
└── i18n/              # переводы
```

## Что работает из коробки

✅ SDK (Yandex + Mock)  
✅ Save/Load (локально + облако)  
✅ State management  
✅ Analytics  
✅ HUD  
✅ Safe area  
✅ Базовые стили

## Что дописать под жанр

- core/merge.ts (merge) или core/clicker.ts (clicker) и т.д.
- ui/grid.ts или ui/button.ts
- Контент в config.ts
- Арт
- Звук
