// Трекинг событий. См. ANALYTICS_BIBLE.

import { sdk } from './sdk';

interface AnalyticsEvent {
  name: string;
  props: Record<string, any>;
  timestamp: number;
  userId?: string;
  sessionId: string;
}

class Analytics {
  private events: AnalyticsEvent[] = [];
  private sessionId: string;
  private userId: string = 'anonymous';
  private counters: Record<string, number> = {};
  private maxLocal = 200;

  constructor() {
    this.sessionId = 'sess_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5);
    sdk.getOwnUniqueId().then(id => this.userId = id);
  }

  track(name: string, props: Record<string, any> = {}) {
    const event: AnalyticsEvent = {
      name,
      props,
      timestamp: Date.now(),
      userId: this.userId,
      sessionId: this.sessionId,
    };
    this.events.push(event);
    if (this.events.length > this.maxLocal) {
      this.events.shift();
    }
    // Также отправляем в Yandex.Metrica если подключено
    if ((window as any).yaCounter) {
      (window as any).yaCounter.reachGoal(name, props);
    }
    // Counter
    this.counters[name] = (this.counters[name] || 0) + 1;
  }

  increment(name: string, delta = 1) {
    this.counters[name] = (this.counters[name] || 0) + 1;
  }

  getCounters() { return { ...this.counters }; }
  getEvents() { return [...this.events]; }
  getSessionId() { return this.sessionId; }
  getUserId() { return this.userId; }
}

export const analytics = new Analytics();

// Хелпер: обёртки для типовых событий
export const track = {
  gameStart: () => analytics.track('game_start'),
  sessionStart: () => analytics.track('session_start'),
  sessionEnd: (length: number) => analytics.track('session_end', { length }),
  
  merge: (level: number, isRare: boolean) =>
    analytics.track('merge', { level, is_rare: isRare }),
  sell: (level: number, money: number) =>
    analytics.track('sell', { level, money }),
  cellUnlock: (index: number, cost: number) =>
    analytics.track('cell_unlock', { index, cost }),
  
  rewardedShown: (type: string) => analytics.track('rewarded_shown', { type }),
  rewardedCompleted: (type: string) => analytics.track('rewarded_completed', { type }),
  rewardedClosed: () => analytics.track('rewarded_closed_early'),
  interstitialShown: (reason: string) => analytics.track('interstitial_shown', { reason }),
  
  dailyClaim: (day: number) => analytics.track('daily_claimed', { day }),
  offlineClaim: (amount: number) => analytics.track('offline_claimed', { amount }),
  
  levelUp: (level: number) => analytics.track('level_up', { level }),
  achievement: (id: string) => analytics.track('achievement', { id }),
  
  error: (msg: string) => analytics.track('error', { msg }),
};
