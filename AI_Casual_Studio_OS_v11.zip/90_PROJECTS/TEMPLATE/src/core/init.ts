// Главный игровой модуль. Адаптировать под жанр.

import { state, addMoney } from './state';
import { analytics, track } from './analytics';
import { initHUD } from './hud';
import { sdk } from './sdk';
import { initI18n } from './i18n';

export function initGame() {
  console.log(`[Game] Init v${state.get().version}`);

  sdk.notifyGameReady();
  initI18n();
  track.gameStart();
  track.sessionStart();

  const app = document.getElementById('app');
  if (app) {
    initHUD(app);
    // Добавить жанровый UI:
    // initGrid(app)      - merge
    // initClicker(app)   - clicker
    // initIdle(app)      - idle
    // initTycoon(app)    - tycoon
  }

  window.addEventListener('beforeunload', () => {
    track.sessionEnd(Date.now() - state.get().firstSeen);
  });

  setTimeout(() => {
    addMoney(10, 'start_bonus');
    track.merge(0, false);
  }, 1000);
}
