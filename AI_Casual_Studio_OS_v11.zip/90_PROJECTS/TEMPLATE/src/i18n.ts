// Простая локализация. Поддержка ru / en.

import { sdk } from './sdk';

type Translations = Record<string, string>;

const ru: Translations = {};
const en: Translations = {};

let currentLang: 'ru' | 'en' = 'ru';
const dict: Record<string, Translations> = { ru, en };

export function initI18n() {
  const lang = sdk.getLanguage();
  currentLang = (lang === 'en' ? 'en' : 'ru') as 'ru' | 'en';
  console.log(`[i18n] Language: ${currentLang}`);
}

export function t(key: string, fallback?: string): string {
  return dict[currentLang]?.[key] || fallback || key;
}

export function getLang() { return currentLang; }
