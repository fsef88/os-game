// Глобальные константы игры. Менять только через feature-флаги, не хардкодить в коде.

export const VERSION = '0.1.0';
export const BUILD = '<date>-<hash>';

// === Game balance ===
export const CONFIG = {
  // стартовые значения
  startingMoney: 100,
  startingLevel: 1,
  
  // прогрессия цены
  costGrowth: 1.5,
  
  // сетка
  gridSize: 4, // 4x4 = 16 клеток
  
  // unlock цены
  slotUnlockCosts: [0, 0, 0, 0, 500, 800, 1500, 2500, 5000, 8000, 25000],
  
  // оффлайн
  offlineEarningPercentage: 0.5,
  maxOfflineTimeSeconds: 14400, // 4 часа
  minOfflineTimeSeconds: 300,   // 5 минут
  offlineEarnCapVsEarned: 3,    // 3x от текущего дохода за онлайн
  
  // редкость
  goldenChance: 0.02,
  rainbowChance: 0.005,
  
  // реклама
  interstitialCooldownSec: 90,
  rewardedCooldownSec: 30,
  maxRewardedPerDay: 10,
  maxInterstitialPerDay: 8,
  
  // бусты
  boost2xDurationMin: 30,
  boost2xMultiplier: 2,
  
  // daily
  dailyRewards: [100, 200, 500, 800, 1500, 2500, 5000],
  dailyStreakBonusDay7: { coins: 5000, crystals: 10, special: 'chest' },
};

// Tier'ы предметов (пример для merge; адаптировать под жанр)
export const VEGETABLES = [
  { id: 0, name: 'Семечко',   cost: 0,    reward: 1 },
  { id: 1, name: 'Росток',    cost: 2,    reward: 3 },
  { id: 2, name: 'Редис',     cost: 5,    reward: 10 },
  { id: 3, name: 'Морковь',   cost: 15,   reward: 30 },
  { id: 4, name: 'Томат',     cost: 40,   reward: 80 },
  { id: 5, name: 'Картофель', cost: 100,  reward: 200 },
  { id: 6, name: 'Огурец',    cost: 250,  reward: 500 },
  { id: 7, name: 'Баклажан',  cost: 600,  reward: 1200 },
  { id: 8, name: 'Перец',     cost: 1500, reward: 3000 },
  { id: 9, name: 'Кабачок',   cost: 3500, reward: 7000 },
  { id: 10, name: 'Тыква',    cost: 8000, reward: 16000 },
];
