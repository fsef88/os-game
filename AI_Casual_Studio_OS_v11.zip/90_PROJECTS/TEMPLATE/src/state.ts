// Глобальное состояние + render паттерн.
// Все мутации через функции, подписки на изменения для UI.

type Listener = () => void;

class StateManager<T> {
  private state: T;
  private listeners: Set<Listener> = new Set();

  constructor(initial: T) {
    this.state = initial;
  }

  get(): T { return this.state; }

  set(updater: Partial<T> | ((s: T) => Partial<T>)) {
    const patch = typeof updater === 'function' ? updater(this.state) : updater;
    this.state = { ...this.state, ...patch };
    this.notify();
  }

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    for (const l of this.listeners) l();
  }
}

// Начальное состояние. Адаптировать под жанр.
const initialState = {
  version: '0.1.0',
  
  // валюта
  money: 100,
  crystals: 0,
  
  // прогресс
  level: 1,
  xp: 0,
  
  // грид (пример для merge)
  grid: Array(16).fill(null).map((_, i) => ({
    index: i,
    isUnlocked: i < 4,
    vegetableLevel: 0,
    isGolden: false,
    isRainbow: false,
  })),
  
  // бусты
  activeBoosts: [] as Array<{ type: string; endTime: number }>,
  
  // квесты
  currentQuest: null as any,
  questProgress: 0,
  
  // достижения
  achievements: [] as string[],
  
  // daily
  dailyStreak: 0,
  dailyLastClaim: 0,
  
  // питомцы (если есть)
  pets: [] as any[],
  
  // аналитика
  sessionCount: 0,
  totalPlayTime: 0,
  firstSeen: Date.now(),
  
  // offline
  offlineEarnings: 0,
};

export const state = new StateManager(initialState);

// Пример мутации
export function addMoney(amount: number, reason = 'unknown') {
  state.set(s => ({ money: s.money + amount }));
  console.log(`[Money] +${amount} (${reason})`);
}

export function spendMoney(amount: number): boolean {
  const current = state.get().money;
  if (current < amount) return false;
  state.set({ money: current - amount });
  return true;
}

export function notifyChange() {
  // для UI-слоя: подписаться через state.subscribe()
}
