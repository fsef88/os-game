# <PROJECT_NAME>

**Жанр:** <merge | clicker | idle | tycoon>  
**Версия:** 0.1  
**Статус:** в разработке

## Что это

<краткое описание, 1-2 предложения>

## Запуск

```bash
cd src
npm install
npm run dev
```

## Документация

- [PROJECT.md](./PROJECT.md) — elevator pitch
- [GAME_DESIGN.md](./GAME_DESIGN.md) — GDD
- [ECONOMY.md](./ECONOMY.md) — экономика
- [BALANCE.md](./BALANCE.md) — баланс
- [ART_DIRECTION.md](./ART_DIRECTION.md) — стиль
- [ANALYTICS.md](./ANALYTICS.md) — события
- [DECISIONS.md](./DECISIONS.md) — решения
- [CHANGELOG.md](./CHANGELOG.md) — изменения

## Код

См. [src/](./src/)

## Статус

- [ ] Setup
- [ ] Core loop
- [ ] UI
- [ ] Save
- [ ] SDK
- [ ] Ads
- [ ] QA
- [ ] Publish
