# 90_PROJECTS

Версия: 1.0
Дата: 2026-07-14

**Tags:** projects

---

Эта папка — **применение** Studio OS. Содержит:

```
90_PROJECTS/
├── README.md          ← вы здесь
├── TEMPLATE/          ← эталонный шаблон нового проекта
│   ├── README.md
│   ├── PROJECT.md
│   ├── GAME_DESIGN.md
│   ├── ECONOMY.md
│   ├── BALANCE.md
│   ├── ART_DIRECTION.md
│   ├── ANALYTICS.md
│   ├── DECISIONS.md
│   ├── CHANGELOG.md
│   └── src/            ← готовая код-база
│       ├── main.ts
│       ├── config.ts
│       ├── state.ts
│       ├── sdk.ts
│       ├── save.ts
│       ├── analytics.ts
│       ├── i18n.ts
│       ├── hud.ts
│       ├── core/
│       ├── styles/
│       └── ui/         ← для компонентов из 16_COMPONENTS/
├── MergeFarm/         ← реальный проект (если будет добавлен)
└── docs/              ← специфичная документация проектов
```

## Как использовать

1. Скопировать `TEMPLATE/` в новую папку
2. Переименовать в название игры
3. Заполнить `PROJECT.md` и `GAME_DESIGN.md`
4. Добавить жанровые файлы в `src/core/`
5. Использовать компоненты из `16_COMPONENTS/`
6. После релиза — обновить Studio OS на основе опыта

## Важно

Эта папка — **НЕ для общей документации**. Только конкретные проекты.
