**Tags:** missing

# MISSING

Список документов, которые упоминаются в существующих правилах, но отсутствуют в Studio OS.
Не создавать автоматически — каждый документ должен отвечать на конкретную боль.

## Высокий приоритет

### Служебные (требуются этой инструкцией)
- [x] PROJECT_STATE.md — создан в v0.5
- [x] CHANGELOG.md — создан в v0.5
- [x] MISSING.md — этот файл
- [x] MERGE_CANDIDATES.md — создан в v0.5
- [x] NEXT_TASK.md — создан в v0.5

### 10_CHECKLISTS
- [ ] POST_RELEASE.md — упоминается в SUCCESS, но не создан
- [ ] MOBILE.md — упоминается в 10_CHECKLISTS, но не создан
- [ ] DESKTOP.md — упоминается в 10_CHECKLISTS, но не создан

### 05_PLAYBOOKS
- [ ] BUILD_CLICKER.md — есть, но это не playbook, а обрывок (24 строки)
- [ ] BUILD_IDLE.md — есть, но это 27 строк. Нужен полноценный 7-day план
- [ ] BUILD_TYCOON.md — есть, но 45 строк. Полноценный план нужен
- [ ] BUILD_PUZZLE.md — есть, но 24 строки. Нужен полноценный
- [ ] QA_PLAYBOOK.md — упоминается в TARGET, но не создан
- [ ] RELEASE_PLAYBOOK.md — есть, но всего 19 строк

### 06_BIBLES
- [ ] YANDEX_GAMES_BIBLE.md — 416 байт, слишком короткий. Нужны: правила модерации, требования SDK, размер билда, запрещённый контент, время модерации, рекламные ограничения.

## Средний приоритет

### 03_ROLES
- [ ] BALANCE_DESIGNER.md (есть, 756 байт) — расширить, добавить кривые прогрессии, формулы дохода, правила удорожания

### 11_REFERENCE
- [ ] Подпапка для жанров (Merge/Idle/Clicker/Tycoon/Puzzle) — сейчас всё в куче
- [ ] STUDIO_PRINCIPLES.md (10248 байт) — гигантский, разделить на 3-5 файлов

### 04_PIPELINE
- [ ] Переходы между стадиями (Stage 1 → Stage 2 → ...) — есть PIPELINE_STAGES, но критерии перехода не описаны

## Низкий приоритет

### 98_EXAMPLES
- [ ] IdleGarden/ — пустой, нужен реальный пример после релиза
- [ ] ClickerTemplate/ — пустой, нужен реальный пример
- [ ] Дополнительные case studies по другим жанрам

### 09_PROMPTS
- [ ] PROMPT_EXTRA_1.md … PROMPT_EXTRA_7.md — переименовать по ролям (GAME_DESIGNER_PROMPT, UX_PROMPT, etc.) или объединить

### Прочее
- [ ] VERSION.md — отдельный файл с историей версий Studio OS
- [ ] DEPLOY.md — инструкция по деплою на Яндекс Игры
- [ ] STACK.md — описание технологического стека (HTML5 + TS + Vite + DOM)
- [ ] SDK_INTEGRATION.md — как подключать Yandex SDK
