# Добро пожаловать в AI Casual Studio OS

Версия: 1.4
Дата: 2026-07-14

**Tags:** core, entry-point

---

## Если ты новый ИИ — начни здесь

Прочитай документы **в этом порядке** перед любой задачей:

### Шаг 1: Понять контекст (3 мин)

- [STUDIO_SCOPE.md](STUDIO_SCOPE.md) — что мы делаем и **что НЕ делаем**
- [NON_GOALS.md](NON_GOALS.md) — что НИКОГДА не делаем
- [ARCHITECTURE.md](ARCHITECTURE.md) — общая схема системы
- [GLOSSARY.md](GLOSSARY.md) — определения всех терминов

### Шаг 2: Понять правила (3 мин)

- [01_BEHAVIOR/HOW_TO_THINK.md](../01_BEHAVIOR/HOW_TO_THINK.md) — как думать
- [01_BEHAVIOR/SELF_REVIEW.md](../01_BEHAVIOR/SELF_REVIEW.md) — после задачи
- [02_RULES/AI_RULES.md](../02_RULES/AI_RULES.md) — формальные правила

### Шаг 3: Понять структуру (2 мин)

- [../INDEX.md](../INDEX.md) — каталог всех документов
- [../DEPENDENCY_MAP.md](../DEPENDENCY_MAP.md) — связи между слоями

### Шаг 4: Понять задачу (5 мин)

- [../PROJECT_STATE.md](../PROJECT_STATE.md) — где находится проект сейчас
- [../FIRST_DAY_CHECKLIST.md](../FIRST_DAY_CHECKLIST.md) — если это новый проект
- [../CHANGELOG.md](../CHANGELOG.md) — что менялось

### Шаг 5: Приступить к работе

Только после шагов 1-4. Иначе ты потратишь время впустую.

---

## Если ты не новый ИИ

Открой [INDEX.md](../INDEX.md) и найди нужный документ по теме задачи.

---

## Если ты Product Owner (человек)

- [STUDIO_SCOPE.md](STUDIO_SCOPE.md) — что мы делаем
- [../CHANGELOG.md](../CHANGELOG.md) — история
- [../PROJECT_STATE.md](../PROJECT_STATE.md) — текущее состояние

---

## Принцип системы

> **Новые документы создаются только если информация не помещается ни в один существующий документ.**

Это правило предотвращает разрастание.

---

## Что дальше

1. Если есть конкретная задача → открой [INDEX.md](../INDEX.md) → найди нужный раздел
2. Если новый проект → [FIRST_DAY_CHECKLIST.md](../FIRST_DAY_CHECKLIST.md) → [BOOTSTRAP_KIT.md](../BOOTSTRAP_KIT.md)
3. Если правишь существующий → обнови PROJECT_STATE.md и CHANGELOG.md после
